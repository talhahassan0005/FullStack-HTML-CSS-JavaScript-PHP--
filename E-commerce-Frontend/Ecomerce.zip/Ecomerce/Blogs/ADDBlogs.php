<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .heading {
            text-align: center;
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
        }

        input[type="text"], textarea, input[type="number"], input[type="file"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box; /* Ensure padding doesn't affect width */
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        .image-input {
            margin-bottom: 10px; /* Adjust spacing between image input and other fields */
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
<div class="container">
        <h1 class="heading">Add Product</h1>
        <form method="post" action="ADDBlogs.php">

            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" name="title" id="title" required>
            </div>
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea name="description" id="description" required></textarea>
            </div>
            <div class="form-group">
                <label for="price">Price:</label>
                <input type="number" name="price" id="price" min="0.01" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="category">Category:</label>
                <input type="text" name="category" id="category" required>
            </div>
            <div class="form-group">
                <label for="brand">Brand:</label>
                <input type="text" name="brand" id="brand" required>
            </div>

        
            <div class="form-group">
                <label for="image">Image:</label>
                <input type="file" name="image" id="image" accept="image/*" required>
            </div> 
            <input type="submit" name="submit" value="Add Product">
        </form>



        <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if all required form fields are not empty
    if (!empty($_POST['title']) && !empty($_POST['description']) && !empty($_POST['price']) && !empty($_POST['category']) && !empty($_POST['brand']) && !empty($_FILES['image'])) {
        // Retrieve form data
        $title = $_POST['title'];
        $description = $_POST['description']; // Corrected variable name
        $price = $_POST['price'];
        $category = $_POST['category'];
        $brand = $_POST['brand'];

        // Check if file upload is successful
        if ($_FILES['image']['error'] === UPLOAD_ERR_OK) {
            // Handle image upload
            $image = addslashes(file_get_contents($_FILES['image']['tmp_name'])); // Read image data and escape special characters

            // Insert data into database
            $sql = "INSERT INTO blogs (Title, Description, Price, Category, Brand, Image)
                    VALUES ('$title', '$description', '$price', '$category', '$brand', '$image')";

            if ($conn->query($sql) === TRUE) {
                echo "New product Blog created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Error uploading file. Please try again.";
        }
    } else {
        echo "All form fields are required.";
    }
}

$conn->close();
?>


    </div>
</body>
</html>
