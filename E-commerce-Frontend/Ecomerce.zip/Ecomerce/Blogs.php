<!DOCTYPE html>
<html lang="en">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="./assets/css/style-prefix.css">
  <title>Blogs For Style</title>
  

</head>
<body>
<?php include 'Header.php';?>

<li style="text-align: center;">
  <div style="display: inline-block;">
    <?php echo '<iframe width="1150" height="450" src="https://www.youtube.com/embed/uXUKjSAU2fo?autoplay=1&mute=1" frameborder="0" allowfullscreen></iframe>'; ?>
  </div>
</li>


    <!--
      - BLOG
    -->

    <div class="blog">

      <div class="container">

        <div class="blog-container has-scrollbar">

          <div class="blog-card">

            <a href="#">
              <img src="./assets/images/blog-1.jpg" alt="Clothes Retail KPIs 2021 Guide for Clothes Executives" width="300" class="blog-banner">
            </a>

            <div class="blog-content">

              <a href="#" class="blog-category">Fashion</a>

              <a href="#">
                <h3 class="blog-title">Fashion is a celebration of diversity,
                   and inclusivity has become an integral part of the industry.
                    Designers are championing diversity on the runways, 
                    featuring models of all shapes, sizes, ages, and backgrounds.
                     By embracing inclusivity, fashion is becoming 
                     more reflective of the rich tapestry of humanity..</h3>
              </a>

              <p class="blog-meta">
              <time datetime="2024-05-11">May 11, 2024</time>

              </p>

            </div>

          </div>

          <div class="blog-card">
          
            <a href="#">
              <img src="./assets/images/blog-2.jpg" alt="Curbside fashion Trends: How to Win the Pickup Battle."
                class="blog-banner" width="300">
            </a>
          
            <div class="blog-content">
          
              <a href="#" class="blog-category">Clothes</a>
          
              <h3>
                <a href="#" class="blog-title">Embrace the latest clothing trends of the season with a burst of sustainable chic,
                   bold colors, and relaxed tailoring. This season, sustainability takes the forefront, 
                   urging us to opt for eco-friendly materials and ethical production practices.
                    Dive into a palette of vibrant hues and playful prints,
                   adding a pop of color to your wardrobe with statement coats or patterned dresses.</a>
              </h3>
          
              <p class="blog-meta">
              <time datetime="2024-05-18">May 18, 2024</time>

              </p>
          
            </div>
          
          </div>

          <div class="blog-card">
          
            <a href="#">
              <img src="./assets/images/blog-3.jpg" alt="EBT vendors: Claim Your Share of SNAP Online Revenue."
                class="blog-banner" width="300">
            </a>
          
            <div class="blog-content">
          
              <a href="#" class="blog-category">Shoes</a>
          
              <h3>
                <a href="#" class="blog-title"> the latest trends in shoes cater to a wide range of tastes and preferences,
                   ensuring that everyone can step out in style, no matter the occasion.
                    Whether you're drawn to the comfort of sneakers, the nostalgia of retro platforms,
                     or the timeless appeal of classic loafers,
                   there's a shoe trend for every fashion enthusiast to embrace and enjoy.</a>
              </h3>
          
              <p class="blog-meta">
              <time datetime="2024-05-10">May 10, 2024</time>

              </p>
          
            </div>
          
          </div>

          <div class="blog-card">
          
            <a href="#">
              <img src="./assets/images/blog-4.jpg" alt="Curbside fashion Trends: How to Win the Pickup Battle."
                class="blog-banner" width="300">
            </a>
          
            <div class="blog-content">
          
              <a href="#" class="blog-category">Jwellary</a>
          
              <h3>
                <a href="#" class="blog-title">the latest trends are all about making a statement with sophistication and flair.
                   From oversized earrings to chunky chains and colorful gemstones, boldness and individuality reign supreme.
                    Mixed metals and intricate designs add a touch of modernity,
                   while vintage-inspired pieces offer a timeless allure..</a>
              </h3>
          
              <p class="blog-meta">
              <time datetime="2024-05-15">May 15, 2024</time>

              </p>
          
            </div>
          
          </div>

        </div>

      </div>

    </div>

 


<?php include 'Footer.php';?>
</body>
</html>