 // JavaScript to toggle content visibility when button is clicked
        document.getElementById('form').addEventListener('click', function() {
            var formContent = document.getElementById('form-content');
            var productForm = document.getElementById('product-form');
            formContent.style.display = 'block'; // Show form content
            productForm.style.display = 'none'; // Hide product form
        });

        document.getElementById('products').addEventListener('click', function() {
            var formContent = document.getElementById('form-content');
            var productForm = document.getElementById('product-form');
            formContent.style.display = 'none'; // Hide form content
            productForm.style.display = 'block'; // Show product form
        });