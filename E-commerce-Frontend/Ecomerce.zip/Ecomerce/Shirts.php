<!DOCTYPE html>
<html lang="en">

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blogs</title>
  <link rel="stylesheet" href="./assets/css/style-prefix.css">

</head>
<body>

<?php include 'Header.php';?>

<ul>
        <li><?php echo '<iframe width="420" height="315" src="https://www.youtube.com/embed/uXUKjSAU2fo" frameborder="0" allowfullscreen></iframe>'; ?></li>
    </ul>


  



<?php include 'Footer.php';?>
</body>
</html>