<!DOCTYPE html>
<html >

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="./assets/css/Aboutus.css">
</head>
<title>About us For Style</title>

<body>

<?php include 'Header.php';?>


  <header>
    <h1>Welcome to the STYLE</h1>
  </header>
  <main>
    <section class="content">
    
      <p>Welcome to Style, your premier destination for all your shopping needs. We're dedicated to providing you with the very best of products, 
        with a focus on quality, affordability, and exceptional customer service..</p>

      <p>Style was founded in 2024  by <b><i>Talha</i></b>. With a passion for delivering top-notch products to customers worldwide, 
        Talha set out to create an online shopping experience that exceeds expectations.
        Starting out as a small operation, we have grown into a thriving e-commerce platform serving customers
         across the globe. Our journey has been marked by continuous improvement and a commitment 
         to excellence in every aspect of our business</p>
    </section>

    <section class="content">
    <ul>
    <li>
        <strong>Wide Range of Products:</strong> From fashion and beauty to electronics and home goods, we offer a diverse selection of high-quality products to suit every taste and lifestyle.
    </li>
    <li>
        <strong>Exceptional Quality:</strong> We source our products from trusted manufacturers and suppliers to ensure that only the best items make it to your doorstep.
    </li>
    <li>
        <strong>Affordable Prices:</strong> We believe that everyone deserves access to great products at reasonable prices. That's why we work hard to keep our prices competitive without compromising on quality.
    </li>
    <li>
        <strong>Secure Shopping Experience:</strong> Your security is our top priority. We use advanced encryption technology to protect your personal information and provide a safe and secure shopping environment.
    </li>
</ul>

    </section>
  </main>
  <?php include 'Footer.php';?>
</body>
</html>

 

