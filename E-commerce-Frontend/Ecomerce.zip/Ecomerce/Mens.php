<!DOCTYPE html>
<html >

<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="./assets/css/style-prefix.css">
</head>
<title>Mens For Style</title>

<body>
<?php include 'Header.php';?>





<div class="product-container">

<div class="container">






  <div class="product-box">

    <!--
      - PRODUCT MINIMAL
    -->

    <div class="product-minimal">

      <div class="product-showcase">

        <h2 class="title">New Arrivals</h2>

        <div class="showcase-wrapper has-scrollbar">

          <div class="showcase-container">

            <div class="showcase">

              <a href="#" class="showcase-img-box">
                <img src="./assets/images/MensShirts.jpeg" alt="relaxed short full sleeve t-shirt" width="70" class="showcase-img">
              </a>

              <div class="showcase-content">

                <a href="#">
                  <h4 class="showcase-title">Relaxed Short full Sleeve T-Shirt</h4>
                </a>

                <a href="#" class="showcase-category">Clothes</a>

                <div class="price-box">
                  <p class="price">$45.00</p>
                  <del>$12.00</del>
                </div>

              </div>

            </div>

            <div class="showcase">
            
              <a href="#" class="showcase-img-box">
                <img src="./assets/images/MenUnstichsuit.jpeg" alt="Unstich Suits embro design top" class="showcase-img" width="70">
              </a>
            
              <div class="showcase-content">
            
                <a href="#">
                  <h4 class="showcase-title">Mens Unstich Suits Embro design Top</h4>
                </a>
            
                <a href="#" class="showcase-category">Clothes</a>
            
                <div class="price-box">
                  <p class="price">$61.00</p>
                  <del>$9.00</del>
                </div>
            
              </div>
            
            </div>

  


    <!--
      - PRODUCT GRID
    -->

    <div class="product-main">

      <h2 class="title">New Products</h2>

      <div class="product-grid">

        <div class="showcase">

          <div class="showcase-banner">

            <img src="./assets/images/products/jacket-3.jpg" alt="Mens Winter Leathers Jackets" width="300" class="product-img default">
            <img src="./assets/images/products/jacket-4.jpg" alt="Mens Winter Leathers Jackets" width="300" class="product-img hover">

            <p class="showcase-badge">15%</p>

            <div class="showcase-actions">

              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>

              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>

              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>

              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>

            </div>

          </div>

          <div class="showcase-content">

            <a href="#" class="showcase-category">jacket</a>

            <a href="#">
              <h3 class="showcase-title">Mens Winter Leathers Jackets</h3>
            </a>

            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>

            <div class="price-box">
              <p class="price">$48.00</p>
              <del>$75.00</del>
            </div>

          </div>

        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/shirt-1.jpg" alt="Pure Garment Dyed Cotton Shirt" class="product-img default"
              width="300">
            <img src="./assets/images/products/shirt-2.jpg" alt="Pure Garment Dyed Cotton Shirt" class="product-img hover"
              width="300">
        
            <p class="showcase-badge angle black">sale</p>
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">shirt</a>
        
            <h3>
              <a href="#" class="showcase-title">Pure Garment Dyed Cotton Shirt</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$45.00</p>
              <del>$56.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/jacket-5.jpg" alt="MEN Yarn Fleece Full-Zip Jacket" class="product-img default"
              width="300">
            <img src="./assets/images/products/jacket-6.jpg" alt="MEN Yarn Fleece Full-Zip Jacket" class="product-img hover"
              width="300">
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">Jacket</a>
        
            <h3>
              <a href="#" class="showcase-title">MEN Yarn Fleece Full-Zip Jacket</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$58.00</p>
              <del>$65.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/MensCoat.jpeg" alt="Mens Coat" class="product-img default"
              width="300">

        
            <p class="showcase-badge angle pink">new</p>
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">skirt</a>
        
            <h3>
              <a href="#" class="showcase-title">Mens Coat</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$25.00</p>
              <del>$35.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/shoe-2.jpg" alt="Casual Men's Brown shoes" class="product-img default"
              width="300">
            <img src="./assets/images/products/shoe-2_1.jpg" alt="Casual Men's Brown shoes" class="product-img hover"
              width="300">
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">casual</a>
        
            <h3>
              <a href="#" class="showcase-title">Casual Men's Brown shoes</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$99.00</p>
              <del>$105.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/watch-3.jpg" alt="Pocket Watch Leather Pouch" class="product-img default"
              width="300">
            <img src="./assets/images/products/watch-4.jpg" alt="Pocket Watch Leather Pouch" class="product-img hover"
              width="300">
        
            <p class="showcase-badge angle black">sale</p>
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">watches</a>
        
            <h3>
              <a href="#" class="showcase-title">Pocket Watch Leather Pouch</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$150.00</p>
              <del>$170.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/watch-1.jpg" alt="Smart watche Vital Plus" class="product-img default"
              width="300">
            <img src="./assets/images/products/watch-2.jpg" alt="Smart watche Vital Plus" class="product-img hover" width="300">
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">watches</a>
        
            <h3>
              <a href="#" class="showcase-title">Smart watche Vital Plus</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$100.00</p>
              <del>$120.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/party-wear-1.jpg" alt="Womens Party Wear Shoes" class="product-img default"
              width="300">
            <img src="./assets/images/products/party-wear-2.jpg" alt="Womens Party Wear Shoes" class="product-img hover"
              width="300">
        
            <p class="showcase-badge angle black">sale</p>
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">party wear</a>
        
            <h3>
              <a href="#" class="showcase-title">Womens Party Wear Shoes</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$25.00</p>
              <del>$30.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/jacket-1.jpg" alt="Mens Winter Leathers Jackets" class="product-img default"
              width="300">
            <img src="./assets/images/products/jacket-2.jpg" alt="Mens Winter Leathers Jackets" class="product-img hover"
              width="300">
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">jacket</a>
        
            <h3>
              <a href="#" class="showcase-title">Mens Winter Leathers Jackets</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$32.00</p>
              <del>$45.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/sports-2.jpg" alt="Trekking & Running Shoes - black" class="product-img default"
              width="300">
            <img src="./assets/images/products/sports-4.jpg" alt="Trekking & Running Shoes - black" class="product-img hover"
              width="300">
        
            <p class="showcase-badge angle black">sale</p>
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">sports</a>
        
            <h3>
              <a href="#" class="showcase-title">Trekking & Running Shoes - black</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$58.00</p>
              <del>$64.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/shoe-1.jpg" alt="Men's Leather Formal Wear shoes" class="product-img default"
              width="300">
            <img src="./assets/images/products/shoe-1_1.jpg" alt="Men's Leather Formal Wear shoes" class="product-img hover"
              width="300">
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">formal</a>
        
            <h3>
              <a href="#" class="showcase-title">Men's Leather Formal Wear shoes</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$50.00</p>
              <del>$65.00</del>
            </div>
        
          </div>
        
        </div>

        <div class="showcase">
        
          <div class="showcase-banner">
            <img src="./assets/images/products/shorts-1.jpg" alt="Better Basics French Terry Sweatshorts"
              class="product-img default" width="300">
            <img src="./assets/images/products/shorts-2.jpg" alt="Better Basics French Terry Sweatshorts"
              class="product-img hover" width="300">
        
            <p class="showcase-badge angle black">sale</p>
        
            <div class="showcase-actions">
              <button class="btn-action">
                <ion-icon name="heart-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="eye-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="repeat-outline"></ion-icon>
              </button>
        
              <button class="btn-action">
                <ion-icon name="bag-add-outline"></ion-icon>
              </button>
            </div>
          </div>
        
          <div class="showcase-content">
            <a href="#" class="showcase-category">shorts</a>
        
            <h3>
              <a href="#" class="showcase-title">Better Basics French Terry Sweatshorts</a>
            </h3>
        
            <div class="showcase-rating">
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
              <ion-icon name="star-outline"></ion-icon>
            </div>
        
            <div class="price-box">
              <p class="price">$78.00</p>
              <del>$85.00</del>
            </div>
        
          </div>
        
        </div>

      </div>

    </div>

  </div>

</div>

</div>





<?php include 'Footer.php';?>
</body>
</html>