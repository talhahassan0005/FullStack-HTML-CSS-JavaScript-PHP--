<!DOCTYPE html>
<html>
<head>
    <title>User Records</title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Delete Data</h2>
    <form method="post" action="">
        ID to delete: <input type="text" name="id">
        <input type="submit" name="submit" value="Delete">
    </form>
    <br>
    <h2>User Records</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
          
        </tr>
        <?php
        // Include the database connection file
        $databaseHost = 'localhost';
        $databaseName = 'test';
        $databaseUsername = 'root';
        $databasePassword = '';
        $mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);
        if($mysqli === false){
            die("ERROR: Could not connect. " . mysqli_connect_error());
        }

        // Check if form is submitted for deletion, then delete record
        if(isset($_POST['submit'])) {
            $id = $_POST['id'];
            $result = mysqli_query($mysqli, "DELETE FROM signup WHERE id=$id");
        }

        // Fetch data from database
        $result = mysqli_query($mysqli, "SELECT * FROM signup");

        // Loop through the fetched data and display it in table rows
        while($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>".$row['ID']."</td>";
            echo "<td>".$row['username']."</td>";
            echo "<td>".$row['email']."</td>";
           
            echo "</tr>";
        }
        ?>
    </table>

    
<?php include 'signup.php';?>
</body>
</html>
